<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Lexik\Bundle\JWTAuthenticationBundle\Encoder\JWTEncoderInterface;
use Symfony\Component\Security\Core\User\UserInterface;

class TokenController extends AbstractController
{
    #[Route('/api/token/verify', name: 'api_token_verify', methods: ['POST'])]
    public function verifyToken(Request $request, JWTEncoderInterface $jwtEncoder): JsonResponse
    {
        $token = $request->headers->get('Authorization');
        $token = str_replace('Bearer ', '', $token);

        try {
            $decodedToken = $jwtEncoder->decode($token);

            return $this->json([
                'status' => 'valid',
                'message' => 'Token jest aktywny',
            ]);
        } catch (\Exception $e) {
            return $this->json([
                'status' => 'invalid',
                'message' => 'Token jest nieaktywny: ' . $e->getMessage()
            ], JsonResponse::HTTP_UNAUTHORIZED);
        }
    }

    #[Route('/api/token/contents', name: 'api_token_contents', methods: ['POST'])]
    public function tokenContents(Request $request, JWTEncoderInterface $jwtEncoder): JsonResponse
    {
        $token = $request->headers->get('Authorization');
        $token = str_replace('Bearer ', '', $token);

        try {
            $decodedToken = $jwtEncoder->decode($token);
			$iat = new \DateTime('@'.$decodedToken['iat']);
			$exp = new \DateTime('@'.$decodedToken['exp']);
            $output = [
                'Token' => $token,
                'Wydany (czas serwera)' => $iat->format('d/m/Y H:i'),
                'Czas wygaśnięcia (czas serwera)' => $exp->format('d/m/Y H:i'),
                'Uprawnienia' => $decodedToken['roles'],
                'Użytkownik' => $decodedToken['username']
            ];

            return $this->json($output);
        } catch (\Exception $e) {
            return $this->json([
                'status' => 'invalid',
                'message' => 'Token jest nieaktywny: ' . $e->getMessage()
            ], JsonResponse::HTTP_UNAUTHORIZED);
        }
    }
}
