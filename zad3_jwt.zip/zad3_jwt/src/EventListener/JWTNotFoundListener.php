<?php

namespace App\EventListener;

use Lexik\Bundle\JWTAuthenticationBundle\Event\JWTNotFoundEvent;
use Symfony\Component\HttpFoundation\JsonResponse;

class JWTNotFoundListener
{
    public function onJWTNotFound(JWTNotFoundEvent $event)
    {
        $data = [
            'message' => 'Brak tokenu, zarejestruj sie i uzyskaj token! JWTNotFound 401',
        ];

        $response = new JsonResponse($data, 401);

        $event->setResponse($response);
    }
    public function onBadRequest($event)
    {
        $data = [
            'message' => 'JsonResponse 400',
        ];

        $response = new JsonResponse($data, 400);

        $event->setResponse($response);
    }
    public function onForbidden($event)
    {
        $data = [
            'message' => 'Nie masz uprawnień do wykonania tej operacji. Forbidden 403',
        ];

        $response = new JsonResponse($data, 403);

        $event->setResponse($response);
    }

    public function onInternalError($event)
    {
        $data = [
            'message' => 'Wystąpił nieoczekiwany błąd. InternalError 500',
        ];

        $response = new JsonResponse($data, 500);

        $event->setResponse($response);
    }
}
